function [noise_imp]=impulse_noise(rx,snrdb,numbits);
K=length(rx);
Eb=(1/numbits)*sum(rx.^2);
%%% impulse noise generation
  M=floor(.01*K);
  noise_imp=zeros(1,K);
  snr=-20;
  Ebn01=10.^(snr./10);
 N01=Eb./Ebn01;
 nstdv1=sqrt(N01./2);
 imp=randperm(K);
 noise_imp(imp(1:M))=nstdv1.*randn(1,M);
     

