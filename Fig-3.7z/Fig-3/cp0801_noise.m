function [noise, noise_imp1]=cp0801_noise(rx,snrdb,numbits);
Eb=(1/numbits)*sum(rx.^2);
K=length(rx);
Ebn0=10.^(snrdb./10);
N0=Eb./Ebn0;
nstdv=sqrt(N0/2);
%%% impulse noise generation
  M=floor(.01*K);
  noise_imp=zeros(1,K);
  noise=zeros(length(Ebn0), K); noise_imp1=noise;
for j=1:length(Ebn0)
    noise(j,:)=nstdv(j).*randn(1,K);
    imp=randperm(K);
    noise_imp(imp(1:M))=10*nstdv(j).*randn(1,M);
    noise_imp1(j,:)= noise_imp;
end