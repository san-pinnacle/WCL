function [MUID]=cp0804_signalshift(MUI,fc,delay);
dt=1/fc;
ss=mod(floor(delay/dt),length(MUI));
 MUID=MUI([end-ss+1:end 1:end-ss]);
