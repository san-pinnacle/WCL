clc;
clear all;
close all;
%% UWB pulse generation
t=linspace(-1e-9,1e-9,33);
dt=t(2)-t(1);
Fs=1/dt;
tau=.35e-9; %% pulsse width parameter
w=(1-(4*pi.*(t/tau).^2)).*exp(-2*pi.*(t/tau).^2); % second derivative 
w=w/norm(w);
%%%%%%%%%%%%%%%%%
Ns=100; % numer of data bits
Tf=100e-9; % frame duration for CM1
dppm=50e-9;
L=floor(Tf*Fs);
bits=randn(Ns,1)>.5;
[stx,ref]=cp0201_trans_PPM_TH_UWB1(Fs,dppm,dt,Ns,Tf,w,bits);

ebno=0:3:30; % CM1 
%ebno=inf;
MM=1000;
ber1=zeros(MM,length(ebno));
 for j=1:MM
[R1,sig]=antenn(stx,L,ebno,Fs,Ns, w,dt,Tf,dppm);
[ber1(j,:)]=cp0801_rx(R1,bits,ebno,Ns,L);
%clear hf noise R ref2 ref1 srake areke L2 S2 tau t   h0 E  R3 nn Sig  
end
ber=sum(ber1)/MM;

 clear srx ref ref1 ho bits ber1 w Tc output Nh Np L i j Ns ns Nf Fs stx noise_imp l dt Tf
 clear dppm MM A D d ii MUI kk ll ho1 delay ref_mui stx_mui cc
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
semilogy(ebno,ber,'-o','color','r','LineWidth',1); hold on;

semilogy(ebno,ber_cm1_imp_quant_10,'--d','color','k','LineWidth',1); hold on

semilogy(ebno,ber_cm1_imp_quant_30_rho_2,'-p','color','b','LineWidth',1); hold on


ber_cm1_imp_quant_30_rho_2

ber_cm1_imp_nonquantized_rho_1_10_times
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
width=3; height=2.5;
figure('Units','inches',...
'Position',[0 0 width height],...
'PaperPositionMode','auto');
semilogy(ebno,ber_cm1_con,'-o','color','k','LineWidth',1,'MarkerSize',5); hold on;
semilogy(ebno,ber_cm1_imp_nonquantized_rho_1_10_times,'-d','color','r','LineWidth',1,'MarkerSize',5); hold on;
%semilogy(ebno,ber_cm1_imp_withoutquant,'-p','color','m','LineWidth',1,'MarkerSize',5,'MarkerEdgeColor','k'); hold on;

semilogy(ebno,ber_cm1_imp_quant_10,'-v','color','b','LineWidth',1,'MarkerSize',5); hold on;
semilogy(ebno,ber_cm1_imp_quant_20,'->','color','g','LineWidth',1,'MarkerSize',5,'MarkerEdgeColor','k'); hold on;
semilogy(ebno,ber_cm1_imp_quant_30,'-x','color','c','LineWidth',1,'MarkerSize',5, 'MarkerEdgeColor','r'); hold on;

semilogy(ebno,ber_cm1_imp_quant_10_rho_2,':v','color','b','LineWidth',1,'MarkerSize',5); hold on;
semilogy(ebno,ber_cm1_imp_quant_20_rho_2,':>','color','g','LineWidth',1,'MarkerSize',5,'MarkerEdgeColor','k'); hold on;
semilogy(ebno,ber_cm1_imp_quant_30_rho_2,':x','color','c','LineWidth',1,'MarkerSize',5, 'MarkerEdgeColor','r'); hold on;

xlabel('SINR (dB)');
ylabel('BER')
[leg,objs]=legend('Con', 'IN', 'IN+Q, \rho=0.01', 'IN+Q, \rho=0.02','IN+Q, \rho=0.03');
[leg,objs]=legend('Con', 'IN', 'IN+Q, INR=10', 'IN+Q, INR=20','IN+Q, INR=30');

set(gca,'xtick',[0:3:30])

set(gca,'ytick',[10^(-4) 10^(-3) 10^(-2) 10^(-1) 1])

print -depsc2 fig2.eps


resizeLegend()