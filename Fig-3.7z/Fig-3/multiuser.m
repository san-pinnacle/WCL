function [mui]=multiuser(stx,L,Fs,Ns, w, dt, Tf,dppm)
% %% MU interference generation
mui2=zeros(100,length(stx));
for ii=1:100
 bits=randn(Ns,1)>.5;
[stx]=cp0201_trans_PPM_TH_UWB1(Fs,dppm,dt,Ns,Tf,w,bits);
% delay=((4)*rand(1) + 1)*1e-9;
% [stx]=cp0804_signalshift(stx1,Fs,delay);
hf=channel_generation(Fs,1,L/2);  
srx1=conv(stx,hf);
Sig=srx1(1:length(stx));
[mui2(ii,:)]=Sig;
clear srx1 stx1 stx bits delay Sig hf
end
mui=sum(mui2);
