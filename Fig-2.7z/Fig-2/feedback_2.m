function [th11 th22]=feedback_2(rx2,numbits,bitsample, th1,th2);
index1=zeros(numbits,1); index2=zeros(numbits,1);
%  for nb=1:numbits %% number of bits 
%            mkk=rx2(1+(nb-1)*bitsample:bitsample+(nb-1)*bitsample);
%            MK1(nb)=(norm(mkk))^2-th2; 
%  end
% zp=1/numbits*sum(MK1); 
 for nb=1:numbits %% number of bits 
   mkk=(rx2(1+(nb-1)*bitsample:bitsample+(nb-1)*bitsample));
            TH1=(norm(mkk))^2-th2;
             if TH1>=th1/1.6
                  index1(nb)=nb;
             else
                  index2(nb)=nb;
              end
end
I1=find(index1); I2=find(index2);
clear nb mkk mkk1 
if length(I1)==1
  mkk=(rx2(1+(I1(1)-1)*bitsample:bitsample+(I1(1)-1)*bitsample));
     tem11=(norm(mkk))^2;   
else   
mkk1=zeros(length(I1),1);
for nb=1:length(I1) %% number of bits 
     mkk=(rx2(1+(I1(nb)-1)*bitsample:bitsample+(I1(nb)-1)*bitsample));
     mkk1(nb,:)=(norm(mkk))^2;
end
tem11=1/length(I1)*sum(mkk1);
end
%% for zero bit
clear nb mkk mkk1 
if length(I2)==1
  mkk=(rx2(1+(I2(1)-1)*bitsample:bitsample+(I2(1)-1)*bitsample));
  tem22=norm(mkk)^2;   
else   
mkk2=zeros(length(I2),1);
for nb=1:length(I2) %% number of bits 
    mkk=(rx2(1+(I2(nb)-1)*bitsample:bitsample+(I2(nb)-1)*bitsample));
     mkk2(nb)=(norm(mkk))^2; 
end
tem22=1/length(I2)*sum(mkk2);
end
th22=(tem22);
th11=(tem11)-th2;

