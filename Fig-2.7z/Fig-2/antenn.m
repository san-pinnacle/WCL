function [R,Sig]=antenn(stx,L, ebno,Fs,Ns,w, dt, Tf,dppm)
% %% single antenna
hf=channel_generation(Fs,1,L/2);  
srx1=conv(stx,hf);
Sig=srx1(1:length(stx));
%% Noise generatation
noise=cp0801_noise(stx,ebno,Ns);
% %% Narrowband generatation
%[nbi]=narrowband(stx,L,Ns);
% %% Impulse noise generatation
[noise_imp]=impulse_noise(stx,ebno,Ns);
% %% multiuser  generatation
%[mui]=multiuser(stx,L,Fs,Ns, w, dt,Tf,dppm);
 %%%%%%%%%%%%%%%%%%%%%%%%
R=zeros(length(ebno),length(Sig));
 for l=1:length(ebno);
R(l,:)=Sig+noise(l,:)+noise_imp;
 end
clear noise_imp srx hf srx1 nbi noise