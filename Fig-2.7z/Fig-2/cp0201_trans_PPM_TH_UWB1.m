function [stx,ref]=cp0201_trans_PPM_TH_UWB1(fc,dppm,dt,numbits,Tf,wtx,bits);
%% PPM TH modulation
framesample=floor(Tf./dt);
ppmsample=floor(dppm./dt);
totallength=framesample*length(bits);
ppmthseq=zeros(1,totallength);
thseq=zeros(1,totallength);
for k=1:length(bits)
index=1+(k-1)*framesample;
thseq(index)=1;
index=index+ppmsample*bits(k);
ppmthseq(index)=1;
end
%%% PPM tranmitter
sa=conv(ppmthseq,wtx);
sb=conv(thseq,wtx);
L1=(floor(Tf*1./dt))*numbits;%size of transmitted pulse
stx=sa(1:L1); % modulated signal
ref=sb(1:L1);%reference siagnal

