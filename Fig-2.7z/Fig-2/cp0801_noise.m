function [noise]=cp0801_noise(rx,snrdb,numbits);
Eb=(1/numbits)*sum(rx.^2);
LL=length(rx);
Ebn0=10.^(snrdb./10);
N0=Eb./Ebn0;
%noise=sqrt(N0/2)*randn(1,LL);
nstdv=sqrt(N0/2);
for j=1:length(Ebn0)
    noise(j,:)=nstdv(j).*randn(1,LL);
end

