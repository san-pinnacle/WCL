function [th1]=feedback(rx2,numbits,bitsample)
 index1=zeros(numbits,1); index2=zeros(numbits,1);

%          for kk=1:length(rx2)
%            if abs(rx2(kk))>= .11  ;%.05 for IN
%                rx2(kk)=1;
%            else 
%                rx2(kk)=0;
%            end 
%         end
 
 for nb=1:numbits %% number of bits 
  mkk=rx2(1+(nb-1)*bitsample:bitsample+(nb-1)*bitsample);
%            for kk=1:bitsample
%            if abs(mkk(kk))>=.05
%                mkk(kk)=1;
%            else 
%                mkk(kk)=0;
%            end 
%            end
          mk1=mkk(1:bitsample/2); mk2=mkk(1+bitsample/2:bitsample);
          MK1=(norm(mk1))^2;  MK2=(norm(mk2))^2;
            if MK1>=MK2
                  index1(nb)=nb;
            else
                  index2(nb)=nb;
            end
end
I1=find(index1); I2=find(index2);
clear nb mkk mkk1 
if length(I1)==1
  mkk=(rx2(1+(I1(1)-1)*bitsample:bitsample+(I1(1)-1)*bitsample));
     tem11=(mkk(1:bitsample/2));   
else   
mkk1=zeros(length(I1),bitsample/2);
for nb=1:length(I1) %% number of bits 
     mkk=(rx2(1+(I1(nb)-1)*bitsample:bitsample+(I1(nb)-1)*bitsample));
     mkk1(nb,:)=mkk(1:bitsample/2);
end
tem11=1/length(I1)*sum(mkk1);
end
%% for one bit
clear nb mkk mkk1 
if length(I2)==1
  mkk=(rx2(1+(I2(1)-1)*bitsample:bitsample+(I2(1)-1)*bitsample));
  tem22=mkk(1+bitsample/2:end);   
else   
mkk2=zeros(length(I2),bitsample/2);
for nb=1:length(I2) %% number of bits 
    mkk=(rx2(1+(I2(nb)-1)*bitsample:bitsample+(I2(nb)-1)*bitsample));
    mkk2(nb,:)=mkk(1+bitsample/2:end);   
end
tem22=1/length(I2)*sum(mkk2);
end
%th2=(tem22);
th1=(tem11+tem22)/2; 

%  for kk=1:bitsample/2
%   if abs(th1(kk))>=.05
%    th1(kk)=1;
%   else 
%   th1(kk)=0;
%   end 
%  end


