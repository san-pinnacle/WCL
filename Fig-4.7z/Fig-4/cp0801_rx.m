function [ber]=cp0801_rx(R,bits,ebno,numbits,bitsample)
%%% Hard decision detection 
[N,LLL]=size(R);
rxbits=zeros(N,numbits);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%\
for n=1:N % for length of snr 
      rx=R(n,:); 
      [thr]=feedback(rx,numbits,bitsample);
          MK1=zeros(numbits,1);
          MK2=MK1;
           for nb=1:numbits %% number of bits 
           mkk=rx(1+(nb-1)*bitsample:bitsample+(nb-1)*bitsample);
           % mkk1=mask(1+(nb-1)*bitsample:bitsample+(nb-1)*bitsample);
%            for kk=1:bitsample
%            if abs(mkk(kk))>=.11;%for AWGN only %% 0.05, for non IN .11
%                mkk(kk)=1;
%            else 
%                mkk(kk)=0;
%            end 
%            
%            if abs(mkk1(kk))>=.11 ;%for AWGN only %% 0.05, for non IN .11
%                mkk1(kk)=1;
%            else 
%                mkk1(kk)=0;
%            end 
%            end
           mk1=mkk(1:bitsample/2); mk2=mkk(1+bitsample/2:bitsample);
%            mk11=mkk1(1:bitsample/2); mk22=mkk1(1+bitsample/2:bitsample);
           % MK1(nb)=sum((mkk.*mkk1)); %
           MK1(nb)=sum((mk1.*thr));  MK2(nb)=sum((mk2.*thr));
    %MK1(nb)=(norm(mk1))^2;  MK2(nb)=(norm(mk2))^2;
           end
        %zp(n)=1/numbits*sum(MK1);     % z2=(1/NT*sum(MK2,2)); 
        %zp=(T1+T2)/2;
        clear mkk1 mkk2  nb 
 for nb=1:numbits %% number of bits 
       if MK1(nb)>=MK2(nb)
       rxbits(n,nb)=0;
       else
       rxbits(n,nb)=1;
       end  %% loop end
 end
end
 %% ber calculation
 ber=zeros(1,N);
 for  n=1:N
        wb=sum(abs(bits'-rxbits(n,:)));
        ber(n)=wb./numbits;
 end
 clear rxbits NOO NO1  mk2 mk1    mkkp  mkd1 mkd2 MK NT LLL N R 
 clear mkk NN1 M N L wb kl mk_window1 mk_window2 nb noise noise1
        
    